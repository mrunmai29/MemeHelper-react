import React from "react";

const Header = () => {
  return (
    <header>
      <div class="header">
  <a href="#default" class="logo">😂 Simple Meme Helper 😂</a>
  <div class="header-right">
    <a class="active" href="#home">By Mrunmai</a>
    <a href="https://github.com/mrunmai29">GitHub</a>
    <a href="https://mrunmai29.github.io/Portfolio/">PortFolio</a>
  </div>
</div>
    </header>
  );
};

export default Header;
